package com.barkod.app.repository;
import com.barkod.app.entity.UserRiskyContent;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.UUID;
public interface UserRiskyContentRepository extends JpaRepository<UserRiskyContent, UUID> {
    List<UserRiskyContent> findByUserId(UUID userId);
}