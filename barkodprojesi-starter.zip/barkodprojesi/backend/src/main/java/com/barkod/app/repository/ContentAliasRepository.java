package com.barkod.app.repository;
import com.barkod.app.entity.ContentAlias;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.Collection;
import java.util.List;
import java.util.UUID;
public interface ContentAliasRepository extends JpaRepository<ContentAlias, UUID> {
    @Query("select a from ContentAlias a where lower(a.normalized) in :norms")
    List<ContentAlias> findByNormalizedIn(Collection<String> norms);
}