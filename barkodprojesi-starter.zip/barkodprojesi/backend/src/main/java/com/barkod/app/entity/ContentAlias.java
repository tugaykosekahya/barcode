package com.barkod.app.entity;

import jakarta.persistence.*;
import java.util.UUID;

@Entity
@Table(name = "content_aliases")
public class ContentAlias {
    @Id @GeneratedValue
    private UUID id;

    @ManyToOne @JoinColumn(name = "content_id")
    private Content content;

    @Column(nullable = false)
    private String alias;

    @Column(nullable = false)
    private String normalized;

    // getters/setters
    public UUID getId(){return id;}
    public Content getContent(){return content;}
    public void setContent(Content c){this.content=c;}
    public String getAlias(){return alias;}
    public void setAlias(String a){this.alias=a;}
    public String getNormalized(){return normalized;}
    public void setNormalized(String n){this.normalized=n;}
}
