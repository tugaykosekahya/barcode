package com.barkod.app.service;

import com.barkod.app.controller.dto.MatchDTO;
import com.barkod.app.controller.dto.ProductDTO;
import com.barkod.app.controller.dto.ScanResultDTO;
import com.barkod.app.entity.Content;
import com.barkod.app.entity.Product;
import com.barkod.app.repository.UserRiskyContentRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Locale;

@Service
public class RiskMatchService {
    private final UserRiskyContentRepository userRiskRepo;

    public RiskMatchService(UserRiskyContentRepository userRiskRepo) {
        this.userRiskRepo = userRiskRepo;
    }

    @Transactional(readOnly = true)
    public ScanResultDTO buildScanResult(Product product, java.util.UUID userId) {
        var userRisks = userRiskRepo.findByUserId(userId);
        var productContentNames = product.getContents().stream()
                .map(Content::getName).map(n -> n==null? "" : n.toLowerCase(Locale.ROOT)).toList();

        var matches = userRisks.stream()
                .filter(ur -> productContentNames.contains(ur.getContent().getName().toLowerCase(Locale.ROOT)))
                .map(ur -> new MatchDTO(
                        ur.getContent().getName(),
                        ur.getContent().getRiskLevel()==null? "unknown" : ur.getContent().getRiskLevel(),
                        ur.getReason()==null? "-" : ur.getReason()
                )).toList();

        boolean hasRisk = !matches.isEmpty();

        var dto = new ProductDTO(
                product.getId(),
                product.getName(),
                product.getBrand(),
                product.getBarcode(),
                product.getContents().stream().map(Content::getName).toList()
        );
        return new ScanResultDTO(dto, hasRisk, matches);
    }
}
