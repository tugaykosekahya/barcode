package com.barkod.app.controller;

import com.barkod.app.controller.dto.ProductDTO;
import com.barkod.app.entity.Content;
import com.barkod.app.entity.FavoriteProduct;
import com.barkod.app.repository.FavoriteProductRepository;
import com.barkod.app.repository.ProductRepository;
import com.barkod.app.repository.UserRepository;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/me/favorites")
public class FavoriteController {
    private final UserRepository userRepo;
    private final FavoriteProductRepository favRepo;
    private final ProductRepository productRepo;

    public FavoriteController(UserRepository ur, FavoriteProductRepository fr, ProductRepository pr) {
        this.userRepo=ur; this.favRepo=fr; this.productRepo=pr;
    }

    private com.barkod.app.entity.User currentUser() {
        String email = (String) SecurityContextHolder.getContext().getAuthentication().getName();
        return userRepo.findByEmail(email).orElseThrow();
    }

    @GetMapping
    public List<ProductDTO> list() {
        var u = currentUser();
        return favRepo.findByUserId(u.getId()).stream()
            .map(fp -> fp.getProduct())
            .map(p -> new ProductDTO(p.getId(), p.getName(), p.getBrand(), p.getBarcode(),
                p.getContents().stream().map(Content::getName).toList()))
            .toList();
    }

    @PostMapping("/{productId}")
    public void add(@PathVariable UUID productId) {
        var u = currentUser();
        var p = productRepo.findById(productId).orElseThrow();
        var f = new FavoriteProduct();
        f.setUser(u); f.setProduct(p); f.setAddedAt(LocalDateTime.now());
        favRepo.save(f);
    }

    @DeleteMapping("/{productId}")
    public void remove(@PathVariable UUID productId) {
        var u = currentUser();
        favRepo.findByUserId(u.getId()).stream()
            .filter(fp -> fp.getProduct().getId().equals(productId))
            .forEach(favRepo::delete);
    }
}
