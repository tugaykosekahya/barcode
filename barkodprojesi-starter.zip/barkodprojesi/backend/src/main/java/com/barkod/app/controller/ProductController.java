package com.barkod.app.controller;

import com.barkod.app.controller.dto.ScanResultDTO;
import com.barkod.app.repository.UserRepository;
import com.barkod.app.service.ScanService;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/products")
public class ProductController {
    private final ScanService scanService;
    private final UserRepository userRepo;

    public ProductController(ScanService ss, UserRepository ur){ this.scanService=ss; this.userRepo=ur; }

    @GetMapping("/scan")
    public ScanResultDTO scan(@RequestParam String barcode) {
        String email = (String) SecurityContextHolder.getContext().getAuthentication().getName();
        var user = userRepo.findByEmail(email).orElseThrow();
        return scanService.scan(barcode, user.getId());
    }
}
