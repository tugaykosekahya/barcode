package com.barkod.app.service;

import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import java.util.List;
import java.util.Optional;

@Component
public class OpenFoodFactsClient {
    private final WebClient webClient = WebClient.builder()
            .baseUrl("https://world.openfoodfacts.org/api/v2")
            .build();

    public Optional<ExternalProduct> fetchByBarcode(String barcode) {
        try {
            ExternalProduct body = webClient.get()
                    .uri("/product/" + barcode + ".json")
                    .retrieve()
                    .bodyToMono(ExternalProduct.class)
                    .onErrorResume(e -> Mono.empty())
                    .block();
            if (body != null && body.isValid()) return Optional.of(body);
            return Optional.empty();
        } catch (Exception e) {
            return Optional.empty();
        }
    }

    public static class ExternalProduct {
        public ProductData product;
        public String status;
        public boolean isValid() { return product != null; }

        public static class ProductData {
            public String product_name;
            public String brands;
            public List<String> ingredients_tags;
        }
    }
}
