package com.barkod.app.controller.dto;
import java.util.UUID;
public record RiskyContentCreateRequest(String contentName, String reason) {}
public record RiskyContentResponse(UUID id, String contentName, String riskLevel, String reason) {}
