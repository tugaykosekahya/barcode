package com.barkod.app.repository;
import com.barkod.app.entity.FavoriteProduct;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.UUID;
public interface FavoriteProductRepository extends JpaRepository<FavoriteProduct, UUID> {
    List<FavoriteProduct> findByUserId(UUID userId);
}