package com.barkod.app.entity;

import jakarta.persistence.*;
import java.util.List;
import java.util.UUID;

@Entity
@Table(name = "contents")
public class Content {
    @Id @GeneratedValue
    private UUID id;

    private String name;
    private String description;
    private String riskLevel;

    @ManyToMany(mappedBy = "contents")
    private List<Product> products;

    // getters/setters
    public UUID getId(){return id;}
    public String getName(){return name;}
    public void setName(String s){this.name=s;}
    public String getDescription(){return description;}
    public void setDescription(String s){this.description=s;}
    public String getRiskLevel(){return riskLevel;}
    public void setRiskLevel(String s){this.riskLevel=s;}
}
