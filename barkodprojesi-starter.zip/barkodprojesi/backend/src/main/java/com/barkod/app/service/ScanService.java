package com.barkod.app.service;

import com.barkod.app.controller.dto.ScanResultDTO;
import com.barkod.app.entity.ProductScanHistory;
import com.barkod.app.entity.User;
import com.barkod.app.repository.ProductScanHistoryRepository;
import com.barkod.app.repository.UserRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.UUID;

@Service
public class ScanService {
    private final ProductService productService;
    private final RiskMatchService riskMatchService;
    private final ProductScanHistoryRepository historyRepo;
    private final UserRepository userRepo;

    public ScanService(ProductService ps, RiskMatchService rms, ProductScanHistoryRepository hr, UserRepository ur) {
        this.productService=ps; this.riskMatchService=rms; this.historyRepo=hr; this.userRepo=ur;
    }

    @Transactional
    public ScanResultDTO scan(String barcode, UUID userId) {
        var user = userRepo.findById(userId).orElseThrow(() -> new EntityNotFoundException("Kullanıcı bulunamadı"));
        var product = productService.getOrCreateProductByBarcode(barcode);
        var result = riskMatchService.buildScanResult(product, userId);

        ProductScanHistory h = new ProductScanHistory();
        h.setUser(user); h.setProduct(product);
        h.setScannedAt(LocalDateTime.now());
        h.setMatchedRiskyContent(result.hasRisk());
        historyRepo.save(h);

        return result;
    }
}
