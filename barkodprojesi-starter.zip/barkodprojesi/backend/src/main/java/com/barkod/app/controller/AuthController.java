package com.barkod.app.controller;

import com.barkod.app.controller.dto.*;
import com.barkod.app.entity.User;
import com.barkod.app.repository.UserRepository;
import com.barkod.app.security.JwtService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDateTime;

@RestController
@RequestMapping("/auth")
public class AuthController {
    private final UserRepository userRepo;
    private final PasswordEncoder encoder;
    private final JwtService jwt;
    private final AuthenticationManager authManager;

    public AuthController(UserRepository ur, PasswordEncoder enc, JwtService jwt, AuthenticationConfiguration cfg) throws Exception {
        this.userRepo=ur; this.encoder=enc; this.jwt=jwt; this.authManager = cfg.getAuthenticationManager();
    }

    @PostMapping("/register")
    public ResponseEntity<TokenResponse> register(@RequestBody RegisterRequest req) {
        userRepo.findByEmail(req.email()).ifPresent(u -> { throw new ResponseStatusException(HttpStatus.CONFLICT, "Email in use"); });
        var user = new User();
        user.setEmail(req.email());
        user.setPasswordHash(encoder.encode(req.password()));
        user.setCreatedAt(LocalDateTime.now());
        userRepo.save(user);
        return ResponseEntity.ok(new TokenResponse(
            jwt.generateAccessToken(req.email()),
            jwt.generateRefreshToken(req.email())
        ));
    }

    @PostMapping("/login")
    public TokenResponse login(@RequestBody LoginRequest req) {
        authManager.authenticate(new UsernamePasswordAuthenticationToken(req.email(), req.password()));
        return new TokenResponse(jwt.generateAccessToken(req.email()), jwt.generateRefreshToken(req.email()));
    }

    @PostMapping("/refresh")
    public TokenResponse refresh(@RequestBody RefreshRequest req) {
        var subject = jwt.extractSubject(req.refreshToken());
        return new TokenResponse(jwt.generateAccessToken(subject), jwt.generateRefreshToken(subject));
    }

    // helper to get current user email if needed
    public static String currentEmail(){
        var a = SecurityContextHolder.getContext().getAuthentication();
        return a==null? null : a.getName();
    }
}
