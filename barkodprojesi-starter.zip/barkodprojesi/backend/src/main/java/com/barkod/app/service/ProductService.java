package com.barkod.app.service;

import com.barkod.app.entity.Content;
import com.barkod.app.entity.Product;
import com.barkod.app.repository.ContentRepository;
import com.barkod.app.repository.ProductRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class ProductService {
    private final ProductRepository productRepo;
    private final ContentRepository contentRepo;
    private final OpenFoodFactsClient offClient;

    public ProductService(ProductRepository productRepo, ContentRepository contentRepo, OpenFoodFactsClient offClient) {
        this.productRepo = productRepo; this.contentRepo = contentRepo; this.offClient = offClient;
    }

    @Transactional
    public Product getOrCreateProductByBarcode(String barcode) {
        return productRepo.findByBarcode(barcode).orElseGet(() ->
            fetchAndPersistExternalProduct(barcode).orElseThrow(() ->
                new EntityNotFoundException("Ürün bulunamadı: " + barcode)));
    }

    private Optional<Product> fetchAndPersistExternalProduct(String barcode) {
        return offClient.fetchByBarcode(barcode).map(ext -> {
            Product p = new Product();
            p.setName(nullSafe(ext.product.product_name));
            p.setBrand(nullSafe(ext.product.brands));
            p.setBarcode(barcode);
            p.setSource("OpenFoodFacts");
            p.setCreatedAt(LocalDateTime.now());

            List<Content> contents = normalize(ext.product.ingredients_tags).stream()
                    .map(this::getOrCreateContentByName)
                    .collect(Collectors.toList());

            p.setContents(contents);
            return productRepo.save(p);
        });
    }

    private Content getOrCreateContentByName(String name) {
        String key = name.toLowerCase(Locale.ROOT);
        return contentRepo.findAll().stream()
                .filter(c -> c.getName()!=null && c.getName().equalsIgnoreCase(key))
                .findFirst()
                .orElseGet(() -> {
                    Content c = new Content();
                    c.setName(key);
                    c.setRiskLevel("unknown");
                    return contentRepo.save(c);
                });
    }

    private static String nullSafe(String s){ return (s==null || s.isBlank()) ? "Bilinmiyor" : s; }

    public static List<String> normalize(List<String> tags) {
        if (tags==null) return List.of();
        return tags.stream()
                .map(t -> t.contains(":") ? t.substring(t.indexOf(':')+1) : t)
                .map(String::toLowerCase)
                .distinct().toList();
    }
}
