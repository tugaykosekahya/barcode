package com.barkod.app.repository;
import com.barkod.app.entity.ProductScanHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.UUID;
public interface ProductScanHistoryRepository extends JpaRepository<ProductScanHistory, UUID> {}
