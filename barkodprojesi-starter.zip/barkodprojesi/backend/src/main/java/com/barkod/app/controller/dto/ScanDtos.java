package com.barkod.app.controller.dto;
import java.util.List;
import java.util.UUID;

public record ProductDTO(UUID id, String name, String brand, String barcode, List<String> contents) {}
public record MatchDTO(String contentName, String riskLevel, String reason) {}
public record ScanResultDTO(ProductDTO product, boolean hasRisk, List<MatchDTO> matches) {}
