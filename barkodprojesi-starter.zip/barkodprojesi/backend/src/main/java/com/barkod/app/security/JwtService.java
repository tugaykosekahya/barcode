package com.barkod.app.security;

import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.time.Duration;
import java.time.Instant;
import java.util.Date;

@Component
public class JwtService {
    @Value("${security.jwt.secret}") private String secret;
    @Value("${security.jwt.access-token-minutes}") private long accessMinutes;
    @Value("${security.jwt.refresh-token-days}") private long refreshDays;

    private Key key(){ return Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8)); }

    public String generateAccessToken(String subject){
        return Jwts.builder().setSubject(subject)
                .setIssuedAt(new Date())
                .setExpiration(Date.from(Instant.now().plus(Duration.ofMinutes(accessMinutes))))
                .signWith(key(), SignatureAlgorithm.HS256).compact();
    }
    public String generateRefreshToken(String subject){
        return Jwts.builder().setSubject(subject)
                .setIssuedAt(new Date())
                .setExpiration(Date.from(Instant.now().plus(Duration.ofDays(refreshDays))))
                .signWith(key(), SignatureAlgorithm.HS256).compact();
    }
    public String extractSubject(String token){
        return Jwts.parserBuilder().setSigningKey(key()).build()
                .parseClaimsJws(token).getBody().getSubject();
    }
}
