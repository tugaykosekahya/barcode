package com.barkod.app.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Entity
@Table(name = "products")
public class Product {
    @Id @GeneratedValue
    private UUID id;

    private String name;
    private String barcode;
    private String brand;
    private String source;
    private LocalDateTime createdAt;

    @ManyToMany
    @JoinTable(
        name = "product_contents",
        joinColumns = @JoinColumn(name = "product_id"),
        inverseJoinColumns = @JoinColumn(name = "content_id")
    )
    private List<Content> contents;

    // getters/setters
    public UUID getId(){return id;}
    public String getName(){return name;}
    public void setName(String s){this.name=s;}
    public String getBarcode(){return barcode;}
    public void setBarcode(String s){this.barcode=s;}
    public String getBrand(){return brand;}
    public void setBrand(String s){this.brand=s;}
    public String getSource(){return source;}
    public void setSource(String s){this.source=s;}
    public LocalDateTime getCreatedAt(){return createdAt;}
    public void setCreatedAt(LocalDateTime t){this.createdAt=t;}
    public List<Content> getContents(){return contents;}
    public void setContents(List<Content> c){this.contents=c;}
}
