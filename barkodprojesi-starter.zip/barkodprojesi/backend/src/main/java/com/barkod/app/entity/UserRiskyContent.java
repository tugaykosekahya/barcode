package com.barkod.app.entity;

import jakarta.persistence.*;
import java.util.UUID;

@Entity
@Table(name = "user_risky_contents")
public class UserRiskyContent {
    @Id @GeneratedValue
    private UUID id;

    @ManyToOne @JoinColumn(name = "user_id")
    private User user;

    @ManyToOne @JoinColumn(name = "content_id")
    private Content content;

    private String reason;

    // getters/setters
    public UUID getId(){return id;}
    public User getUser(){return user;}
    public void setUser(User u){this.user=u;}
    public Content getContent(){return content;}
    public void setContent(Content c){this.content=c;}
    public String getReason(){return reason;}
    public void setReason(String r){this.reason=r;}
}
