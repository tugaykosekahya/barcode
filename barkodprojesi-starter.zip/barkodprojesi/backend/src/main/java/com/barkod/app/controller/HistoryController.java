package com.barkod.app.controller;

import com.barkod.app.entity.ProductScanHistory;
import com.barkod.app.repository.ProductScanHistoryRepository;
import com.barkod.app.repository.UserRepository;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.Comparator;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/me/history")
public class HistoryController {
    private final UserRepository userRepo;
    private final ProductScanHistoryRepository histRepo;

    public HistoryController(UserRepository ur, ProductScanHistoryRepository hr) {
        this.userRepo=ur; this.histRepo=hr;
    }

    private com.barkod.app.entity.User currentUser() {
        String email = (String) SecurityContextHolder.getContext().getAuthentication().getName();
        return userRepo.findByEmail(email).orElseThrow();
    }

    @GetMapping
    public List<Map<String, Object>> list() {
        var u = currentUser();
        return histRepo.findAll().stream()
            .filter(h -> h.getUser().getId().equals(u.getId()))
            .sorted(Comparator.comparing(ProductScanHistory::getScannedAt).reversed())
            .map(h -> Map.of(
                "productId", h.getProduct().getId(),
                "name", h.getProduct().getName(),
                "brand", h.getProduct().getBrand(),
                "barcode", h.getProduct().getBarcode(),
                "scannedAt", h.getScannedAt(),
                "hasRisk", h.isMatchedRiskyContent()
            )).toList();
    }
}
