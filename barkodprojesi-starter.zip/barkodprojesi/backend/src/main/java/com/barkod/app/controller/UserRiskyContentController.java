package com.barkod.app.controller;

import com.barkod.app.controller.dto.RiskyContentCreateRequest;
import com.barkod.app.controller.dto.RiskyContentResponse;
import com.barkod.app.entity.Content;
import com.barkod.app.entity.User;
import com.barkod.app.entity.UserRiskyContent;
import com.barkod.app.repository.ContentRepository;
import com.barkod.app.repository.UserRepository;
import com.barkod.app.repository.UserRiskyContentRepository;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Locale;
import java.util.UUID;

@RestController
@RequestMapping("/me/risky-contents")
public class UserRiskyContentController {
    private final UserRepository userRepo;
    private final ContentRepository contentRepo;
    private final UserRiskyContentRepository userRiskRepo;

    public UserRiskyContentController(UserRepository ur, ContentRepository cr, UserRiskyContentRepository urr){
        this.userRepo=ur; this.contentRepo=cr; this.userRiskRepo=urr;
    }

    private User currentUser() {
        String email = (String) SecurityContextHolder.getContext().getAuthentication().getName();
        return userRepo.findByEmail(email).orElseThrow();
    }

    @GetMapping
    public List<RiskyContentResponse> list() {
        var u = currentUser();
        return userRiskRepo.findByUserId(u.getId()).stream()
            .map(ur -> new RiskyContentResponse(
                ur.getId(),
                ur.getContent().getName(),
                ur.getContent().getRiskLevel(),
                ur.getReason()
            )).toList();
    }

    @PostMapping
    public RiskyContentResponse add(@RequestBody RiskyContentCreateRequest req) {
        var u = currentUser();
        String norm = req.contentName()==null? "" : req.contentName().toLowerCase(Locale.ROOT);
        var content = contentRepo.findAll().stream()
            .filter(c -> c.getName()!=null && c.getName().equalsIgnoreCase(norm))
            .findFirst()
            .orElseGet(() -> {
                var c = new Content();
                c.setName(norm);
                c.setRiskLevel("unknown");
                return contentRepo.save(c);
            });
        var ur = new UserRiskyContent();
        ur.setUser(u); ur.setContent(content); ur.setReason(req.reason());
        userRiskRepo.save(ur);
        return new RiskyContentResponse(ur.getId(), content.getName(), content.getRiskLevel(), ur.getReason());
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable UUID id) {
        var u = currentUser();
        var item = userRiskRepo.findById(id).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
        if (!item.getUser().getId().equals(u.getId()))
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Not owner");
        userRiskRepo.delete(item);
    }
}
