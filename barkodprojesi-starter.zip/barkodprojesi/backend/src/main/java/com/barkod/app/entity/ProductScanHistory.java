package com.barkod.app.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "product_scan_history")
public class ProductScanHistory {
    @Id @GeneratedValue
    private UUID id;

    @ManyToOne @JoinColumn(name = "user_id")
    private User user;

    @ManyToOne @JoinColumn(name = "product_id")
    private Product product;

    private LocalDateTime scannedAt;
    private boolean matchedRiskyContent;

    // getters/setters
    public UUID getId(){return id;}
    public User getUser(){return user;}
    public void setUser(User u){this.user=u;}
    public Product getProduct(){return product;}
    public void setProduct(Product p){this.product=p;}
    public LocalDateTime getScannedAt(){return scannedAt;}
    public void setScannedAt(LocalDateTime t){this.scannedAt=t;}
    public boolean isMatchedRiskyContent(){return matchedRiskyContent;}
    public void setMatchedRiskyContent(boolean m){this.matchedRiskyContent=m;}
}
