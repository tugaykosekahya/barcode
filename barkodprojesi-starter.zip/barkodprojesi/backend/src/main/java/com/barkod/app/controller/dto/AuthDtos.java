package com.barkod.app.controller.dto;
public record RegisterRequest(String email, String password) {}
public record LoginRequest(String email, String password) {}
public record TokenResponse(String accessToken, String refreshToken) {}
public record RefreshRequest(String refreshToken) {}
