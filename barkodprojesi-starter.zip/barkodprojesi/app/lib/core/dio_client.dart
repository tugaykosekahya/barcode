import 'package:dio/dio.dart';
import 'config.dart';
import 'token_storage.dart';

Dio createDio(TokenStorage storage) {
  final dio = Dio(BaseOptions(baseUrl: AppConfig.apiBaseUrl, connectTimeout: const Duration(seconds: 8)));
  dio.interceptors.add(QueuedInterceptorsWrapper(
    onRequest: (o, h) async {
      final token = await storage.access;
      if (token != null) o.headers['Authorization'] = 'Bearer $token';
      h.next(o);
    },
    onError: (e, h) async {
      final is401 = e.response?.statusCode == 401;
      final req = e.requestOptions;
      if (is401 && !req.extra.containsKey('retried')) {
        final refresh = await storage.refresh;
        if (refresh != null) {
          try {
            final r = await Dio(BaseOptions(baseUrl: AppConfig.apiBaseUrl))
                .post('/auth/refresh', data: {'refreshToken': refresh});
            final access = r.data['accessToken'] as String;
            final newRefresh = r.data['refreshToken'] as String;
            await storage.save(access, newRefresh);
            final clone = await dio.fetch(req..headers['Authorization'] = 'Bearer $access'..extra['retried']=true);
            return h.resolve(clone);
          } catch (_) {}
        }
      }
      h.next(e);
    },
  ));
  return dio;
}
