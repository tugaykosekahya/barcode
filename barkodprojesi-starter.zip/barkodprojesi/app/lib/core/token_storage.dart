import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class TokenStorage {
  final _s = const FlutterSecureStorage();
  Future<void> save(String access, String refresh) async {
    await _s.write(key: 'access', value: access);
    await _s.write(key: 'refresh', value: refresh);
  }
  Future<String?> get access async => _s.read(key: 'access');
  Future<String?> get refresh async => _s.read(key: 'refresh');
  Future<void> clear() async { await _s.deleteAll(); }
}
