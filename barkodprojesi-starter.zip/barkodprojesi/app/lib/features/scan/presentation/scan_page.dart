import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:go_router/go_router.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import '../../../core/dio_client.dart';
import '../data/scan_api.dart';

final scanApiProvider = Provider((ref) => ScanApi(ref.read(dioProvider)));

class ScanPage extends ConsumerStatefulWidget {
  const ScanPage({super.key});
  @override
  ConsumerState<ScanPage> createState() => _ScanPageState();
}

class _ScanPageState extends ConsumerState<ScanPage> {
  bool locked = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Barkod Tara')),
      body: MobileScanner(
        allowDuplicates: false,
        onDetect: (capture) async {
          if (locked) return;
          final code = capture.barcodes.first.rawValue;
          if (code == null) return;
          setState(()=>locked=true);
          try {
            final data = await ref.read(scanApiProvider).scan(code);
            if (mounted) context.push('/result', extra: data);
          } catch (e) {
            if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Bulunamadı/Hata: $e')));
          } finally { if (mounted) setState(()=>locked=false); }
        },
      ),
    );
  }
}
