import 'package:flutter/material.dart';

class ScanResultPage extends StatelessWidget {
  const ScanResultPage({super.key, required this.result});
  final Object? result;

  @override
  Widget build(BuildContext context) {
    final map = (result as Map?) ?? {};
    final product = (map['product'] as Map?) ?? {};
    final matches = (map['matches'] as List?) ?? [];
    final hasRisk = map['hasRisk'] == true;

    return Scaffold(
      appBar: AppBar(title: Text(product['name'] ?? 'Ürün')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              Expanded(child: Text('${product['brand'] ?? '-'} / ${product['barcode'] ?? '-'}')),
              Chip(label: Text(hasRisk ? 'RİSKLİ' : 'GÜVENLİ'), backgroundColor: hasRisk ? Colors.redAccent.withOpacity(.2) : Colors.greenAccent.withOpacity(.2)),
            ]),
            const SizedBox(height: 16),
            Text('İçerikler', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              children: ((product['contents'] as List?) ?? []).map<Widget>((c) => Chip(label: Text('$c'))).toList(),
            ),
            const Divider(height: 32),
            Text('Eşleşen Riskler', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            if (matches.isEmpty) const Text('Eşleşme yok.')
            else ...matches.map((m) => ListTile(
              leading: const Icon(Icons.warning_amber),
              title: Text((m as Map)['contentName'] ?? '-'),
              subtitle: Text('Seviye: ${(m as Map)['riskLevel'] ?? 'unknown'} — Neden: ${(m as Map)['reason'] ?? '-'}'),
            )),
          ],
        ),
      ),
    );
  }
}
