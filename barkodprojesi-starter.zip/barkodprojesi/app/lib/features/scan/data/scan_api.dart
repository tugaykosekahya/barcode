import 'package:dio/dio.dart';

class ScanApi {
  ScanApi(this._dio);
  final Dio _dio;

  Future<Map<String, dynamic>> scan(String barcode) async {
    final r = await _dio.get('/api/products/scan', queryParameters: {'barcode': barcode});
    return (r.data as Map).cast<String, dynamic>();
  }
}
