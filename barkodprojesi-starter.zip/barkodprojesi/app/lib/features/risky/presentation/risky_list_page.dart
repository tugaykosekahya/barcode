import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import '../controllers/risky_controller.dart';

class RiskyListPage extends ConsumerWidget {
  const RiskyListPage({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(riskyListProvider);
    final name = TextEditingController();
    final reason = TextEditingController();

    return Scaffold(
      appBar: AppBar(title: const Text('Riskli İçeriklerim')),
      body: async.when(
        data: (items) => Column(
          children: [
            Expanded(child: ListView.builder(
              itemCount: items.length,
              itemBuilder: (_, i) {
                final it = items[i];
                return ListTile(
                  leading: const Icon(Icons.report),
                  title: Text(it['contentName'] ?? '-'),
                  subtitle: Text('Seviye: ${it['riskLevel']}  •  Neden: ${it['reason']}'),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete),
                    onPressed: () async {
                      await ref.read(riskyApiProvider).remove(it['id']);
                      ref.invalidate(riskyListProvider);
                    },
                  ),
                );
              },
            )),
            Padding(
              padding: const EdgeInsets.all(12),
              child: Row(children: [
                Expanded(child: TextField(controller: name, decoration: const InputDecoration(hintText: 'İçerik adı (örn: aspartame)'))),
                const SizedBox(width: 8),
                Expanded(child: TextField(controller: reason, decoration: const InputDecoration(hintText: 'Neden'))),
                const SizedBox(width: 8),
                ElevatedButton(onPressed: () async {
                  await ref.read(riskyApiProvider).add(name.text.trim(), reason.text.trim());
                  name.clear(); reason.clear();
                  ref.invalidate(riskyListProvider);
                }, child: const Text('Ekle')),
              ]),
            )
          ],
        ),
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('Hata: $e')),
      ),
    );
  }
}
