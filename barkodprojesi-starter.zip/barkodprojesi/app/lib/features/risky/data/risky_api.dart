import 'package:dio/dio.dart';

class RiskyApi {
  RiskyApi(this._dio);
  final Dio _dio;

  Future<List<Map<String, dynamic>>> list() async {
    final r = await _dio.get('/me/risky-contents');
    return (r.data as List).map((e) => (e as Map).cast<String, dynamic>()).toList();
  }
  Future<void> add(String name, String reason) async {
    await _dio.post('/me/risky-contents', data: {'contentName': name, 'reason': reason});
  }
  Future<void> remove(String id) async {
    await _dio.delete('/me/risky-contents/$id');
  }
}
