import 'package:hooks_riverpod/hooks_riverpod.dart';
import '../../../core/dio_client.dart';
import '../data/risky_api.dart';

final riskyApiProvider = Provider((ref) => RiskyApi(ref.read(dioProvider)));

final riskyListProvider = FutureProvider.autoDispose((ref) async {
  return ref.read(riskyApiProvider).list();
});
