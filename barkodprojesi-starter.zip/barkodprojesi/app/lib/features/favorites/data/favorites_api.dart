import 'package:dio/dio.dart';

class FavoritesApi {
  FavoritesApi(this._dio);
  final Dio _dio;
  Future<List<Map<String, dynamic>>> list() async {
    final r = await _dio.get('/me/favorites'); return (r.data as List).map((e)=> (e as Map).cast<String,dynamic>()).toList();
  }
  Future<void> add(String productId) async => _dio.post('/me/favorites/$productId');
  Future<void> remove(String productId) async => _dio.delete('/me/favorites/$productId');
}
