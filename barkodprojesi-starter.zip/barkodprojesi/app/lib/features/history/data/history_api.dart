import 'package:dio/dio.dart';

class HistoryApi {
  HistoryApi(this._dio);
  final Dio _dio;
  Future<List<Map<String, dynamic>>> list() async {
    final r = await _dio.get('/me/history'); return (r.data as List).map((e)=> (e as Map).cast<String,dynamic>()).toList();
  }
}
