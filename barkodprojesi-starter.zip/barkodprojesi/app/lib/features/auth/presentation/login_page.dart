import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import '../controllers/auth_controller.dart';
import 'package:go_router/go_router.dart';

class LoginPage extends ConsumerStatefulWidget {
  const LoginPage({super.key});
  @override
  ConsumerState<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends ConsumerState<LoginPage> {
  final email = TextEditingController();
  final pass = TextEditingController();
  bool busy = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Giriş')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(children: [
          TextField(controller: email, decoration: const InputDecoration(labelText: 'Email')),
          TextField(controller: pass, decoration: const InputDecoration(labelText: 'Şifre'), obscureText: true),
          const SizedBox(height: 12),
          ElevatedButton(
            onPressed: busy ? null : () async {
              setState(()=>busy=true);
              try {
                await ref.read(authRepoProvider).login(email.text.trim(), pass.text);
                if (mounted) context.go('/');
              } catch (e) {
                if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Hata: $e')));
              } finally { if (mounted) setState(()=>busy=false); }
            },
            child: const Text('Giriş yap'),
          ),
          TextButton(onPressed: ()=>context.go('/register'), child: const Text('Hesap oluştur')),
        ]),
      ),
    );
  }
}
