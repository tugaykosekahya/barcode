import '../../..//core/token_storage.dart';
import 'auth_api.dart';

class AuthRepository {
  AuthRepository(this.api, this.storage);
  final AuthApi api;
  final TokenStorage storage;

  Future<void> login(String email, String password) async {
    final (a, r) = await api.login(email, password);
    await storage.save(a, r);
  }
  Future<void> register(String email, String password) async {
    final (a, r) = await api.register(email, password);
    await storage.save(a, r);
  }
  Future<void> logout() => storage.clear();
}
