import 'package:dio/dio.dart';

class AuthApi {
  AuthApi(this._dio);
  final Dio _dio;

  Future<(String access, String refresh)> register(String email, String password) async {
    final r = await _dio.post('/auth/register', data: {'email': email, 'password': password});
    return (r.data['accessToken'], r.data['refreshToken']);
  }
  Future<(String access, String refresh)> login(String email, String password) async {
    final r = await _dio.post('/auth/login', data: {'email': email, 'password': password});
    return (r.data['accessToken'], r.data['refreshToken']);
  }
}
