import 'package:hooks_riverpod/hooks_riverpod.dart';
import '../../../core/dio_client.dart';
import '../../../core/token_storage.dart';
import '../data/auth_api.dart';
import '../data/auth_repository.dart';

final authRepoProvider = Provider((ref) => AuthRepository(
  AuthApi(ref.read(dioProvider)), ref.read(tokenStorageProvider)));

final isLoggedInProvider = FutureProvider<bool>((ref) async {
  final t = await ref.read(tokenStorageProvider).access;
  return t != null;
});
