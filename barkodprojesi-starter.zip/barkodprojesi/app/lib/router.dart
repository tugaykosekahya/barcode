import 'package:go_router/go_router.dart';
import 'features/auth/presentation/login_page.dart';
import 'features/auth/presentation/register_page.dart';
import 'features/scan/presentation/scan_page.dart';
import 'features/scan/presentation/scan_result_page.dart';
import 'features/risky/presentation/risky_list_page.dart';
import 'features/favorites/data/favorites_api.dart';
import 'features/history/data/history_api.dart';

final router = GoRouter(
  routes: [
    GoRoute(path: '/', builder: (_, __) => const ScanPage()),
    GoRoute(path: '/login', builder: (_, __) => const LoginPage()),
    GoRoute(path: '/register', builder: (_, __) => const RegisterPage()),
    GoRoute(path: '/result', builder: (_, s) => ScanResultPage(result: s.extra)),
    GoRoute(path: '/risky', builder: (_, __) => const RiskyListPage()),
  ],
);
