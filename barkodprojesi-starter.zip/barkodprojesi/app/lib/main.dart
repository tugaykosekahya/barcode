import 'package:flutter/material.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'core/token_storage.dart';
import 'core/dio_client.dart';
import 'router.dart';

final tokenStorageProvider = Provider<TokenStorage>((ref) => TokenStorage());
final dioProvider = Provider((ref) => createDio(ref.read(tokenStorageProvider)));

void main() {
  runApp(const ProviderScope(child: App()));
}

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp.router(
      title: 'Barkod Asistan',
      theme: ThemeData(useMaterial3: true),
      routerConfig: router,
    );
  }
}
